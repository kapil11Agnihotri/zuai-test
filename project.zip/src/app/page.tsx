import SideBar from '@/components/SideBar';

export default function Home() {
  return (
    <div className="p-3 m-1" style={{backgroundColor:'#fff',width:'70px',height:"98.5dvh",borderRadius:"20px"}}>
     <SideBar/>
    </div>
  );
}